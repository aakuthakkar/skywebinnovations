<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminUserSeeder extends Seeder
{
    public function run(): void
    {
        $email = 'admin@skywebinnovations.com';
        $password = 'Admin@123456';

        $user = User::where('email', $email)->first();

        if ($user) {
            $user->update([
                'name' => 'Admin',
                'password' => Hash::make($password),
                'email_verified_at' => now(),
            ]);
            echo "Admin user updated!" . PHP_EOL;
        } else {
            User::create([
                'name' => 'Admin',
                'email' => $email,
                'password' => Hash::make($password),
                'email_verified_at' => now(),
            ]);
            echo "Admin user created!" . PHP_EOL;
        }

        echo "Email: {$email}" . PHP_EOL;
        echo "Password: {$password}" . PHP_EOL;
    }
}
