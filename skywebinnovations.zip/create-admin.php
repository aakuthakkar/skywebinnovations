<?php
require 'd:/skywebinnovations/vendor/autoload.php';
$app = require 'd:/skywebinnovations/bootstrap/app.php';
$kernel = $app->make(\Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\User;
use Illuminate\Support\Facades\Hash;

$exists = User::where('email', 'admin@skywebinnovations.com')->exists();
if (!$exists) {
    User::create([
        'name' => 'Admin',
        'email' => 'admin@skywebinnovations.com',
        'email_verified_at' => now(),
        'password' => Hash::make('admin123'),
    ]);
    echo "Admin user created: admin@skywebinnovations.com\n";
} else {
    echo "Admin user already exists\n";
}
