<?php
// clear-cache.php - Run this in browser: https://skywebinnovations.com/clear-cache.php
// DELETE this file after use for security!

$output = [];
$basePath = __DIR__;

// Clear Laravel caches
$commands = [
    'php artisan config:clear',
    'php artisan route:clear',
    'php artisan view:clear',
    'php artisan cache:clear',
];

foreach ($commands as $cmd) {
    exec($cmd . ' 2>&1', $output);
}

// Also manually clear cache files
$dirs = [
    $basePath . '/storage/framework/views',
    $basePath . '/storage/framework/cache',
    $basePath . '/storage/framework/sessions',
    $basePath . '/bootstrap/cache',
];

foreach ($dirs as $dir) {
    if (is_dir($dir)) {
        $files = glob($dir . '/*');
        foreach ($files as $file) {
            if (is_file($file)) {
                @unlink($file);
            }
        }
    }
}

echo "<h2>Cache Cleared Successfully!</h2>";
echo "<p>All Laravel caches have been cleared.</p>";
echo "<p><strong>IMPORTANT:</strong> Delete this file (clear-cache.php) now for security.</p>";
echo '<p><a href="/">Go to Homepage</a></p>';
