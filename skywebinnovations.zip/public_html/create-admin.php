<?php
// create-admin.php - Run this in browser: https://skywebinnovations.com/create-admin.php
// DELETE this file after use for security!

$dbFile = __DIR__ . '/../database/database.sqlite';

// Try MySQL first (live server)
$mysqlHost = getenv('DB_HOST') ?: '127.0.0.1';
$mysqlUser = getenv('DB_USERNAME') ?: 'root';
$mysqlPass = getenv('DB_PASSWORD') ?: '';
$mysqlDb   = getenv('DB_DATABASE') ?: 'skywotut_skyweb';

try {
    $pdo = new PDO("mysql:host=$mysqlHost;dbname=$mysqlDb;charset=utf8mb4", $mysqlUser, $mysqlPass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $email = 'admin@skywebinnovations.com';
    $password = password_hash('Admin@123456', PASSWORD_BCRYPT);

    $stmt = $pdo->prepare("INSERT INTO users (name, email, password, email_verified_at, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW(), NOW())");
    $stmt->execute(['Admin', $email, $password]);

    echo "<h2>Admin User Created!</h2>";
    echo "<p><strong>Email:</strong> admin@skywebinnovations.com</p>";
    echo "<p><strong>Password:</strong> Admin@123456</p>";
    echo "<p><a href='/login'>Go to Login</a></p>";
    echo "<hr><p><strong>IMPORTANT:</strong> Delete this file (create-admin.php) now for security!</p>";
    exit;
} catch (PDOException $e) {
    echo "<h2>MySQL Error:</h2>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<p>Make sure .env has correct DB credentials.</p>";
}
