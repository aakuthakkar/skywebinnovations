@props([
    'title' => null,
    'description' => null,
    'image' => null,
    'author' => null,
    'keywords' => null,
    'type' => 'website',
    'canonical' => null,
    'services' => [],
    'faqItems' => [],
])

<?php
    $settings = $settings ?? [];
    $title = $title ?: ($settings['meta_title'] ?? 'Sky Web Innovations | Website, SaaS & Custom Software Development Company');
    $description = $description ?: ($settings['meta_description'] ?? 'Sky Web Innovations designs and builds websites, custom web applications and SaaS products for businesses in the US, Canada, Australia, New Zealand and the UK.');
    $image = $image ?: ($settings['meta_image'] ?? '/assets/og-image.jpg');
    $imageFull = preg_match('#^https?://#', $image) ? $image : (config('app.url') . $image);
    $author = $author ?: ($settings['founder_name'] ?? 'Aakash Thakkar');
    $keywords = $keywords ?: ($settings['meta_keywords'] ?? 'web development, custom software, SaaS, Laravel, React, web applications, website design, digital products, web agency');
    $canonical = $canonical ?: url()->current();
    $url = config('app.url');
    $siteName = $settings['site_name'] ?? 'Sky Web Innovations';
    $locale = 'en_US';
?>
<title>{{ $title }}</title>
<meta name="description" content="{{ $description }}">
<meta name="keywords" content="{{ $keywords }}">
<meta name="author" content="{{ $author }}">
<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
<meta name="revisit-after" content="7 days">
<link rel="canonical" href="{{ $canonical }}">

<!-- Open Graph -->
<meta property="og:type" content="{{ $type }}">
<meta property="og:site_name" content="{{ $siteName }}">
<meta property="og:locale" content="{{ $locale }}">
<meta property="og:title" content="{{ $title }}">
<meta property="og:description" content="{{ $description }}">
<meta property="og:url" content="{{ $canonical }}">
<meta property="og:image" content="{{ $imageFull }}">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="{{ $siteName }}">

<!-- Twitter Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{{ $title }}">
<meta name="twitter:description" content="{{ $description }}">
<meta name="twitter:image" content="{{ $imageFull }}">
<meta name="twitter:creator" content="{{ $settings['twitter_handle'] ?? '@skywebinnovations' }}">
<!-- Favicon -->
<link rel="icon" type="image/png" sizes="32x32" href="{{ asset('favicon-32x32.png') }}">
<link rel="icon" type="image/png" sizes="16x16" href="{{ asset('favicon-16x16.png') }}">
<link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}">
<link rel="apple-touch-icon" sizes="180x180" href="{{ asset('apple-touch-icon.png') }}">
<meta name="theme-color" content="#14152a">

<!-- Alternate language versions -->
<link rel="alternate" hreflang="en-us" href="{{ $url }}/">
<link rel="alternate" hreflang="en-ca" href="{{ $url }}/">
<link rel="alternate" hreflang="en-au" href="{{ $url }}/">
<link rel="alternate" hreflang="en-nz" href="{{ $url }}/">
<link rel="alternate" hreflang="en-gb" href="{{ $url }}/">
<link rel="alternate" hreflang="x-default" href="{{ $url }}/">

<!-- Preconnect for performance -->
<link rel="preconnect" href="https://www.googletagmanager.com">

@php
    $servicesArray = $services instanceof \Illuminate\Support\Collection ? $services : collect($services ?? []);
    $faqArray = $faqItems instanceof \Illuminate\Support\Collection ? $faqItems : collect($faqItems ?? []);
    $orgUrl = $url;
    $orgName = $siteName;
    $orgEmail = $settings['contact_email'] ?? 'info@skywebinnovations.com';
    $orgPhone = $settings['contact_phone'] ?? '+91-7990903773';
    $founderName = $settings['founder_name'] ?? 'Aakash Thakkar';
    $founderLinkedin = $settings['linkedin_url'] ?? 'https://www.linkedin.com/in/aakash-thakkar-a8b9a988/';
    $logoUrl = $url . '/assets/logo.jpeg';
    $servicesForSchema = collect($servicesArray)->map(fn($s) => ['@type' => 'Service', 'name' => is_object($s) ? $s->name : $s])->take(7);
    $faqForSchema = collect($faqArray)->take(6)->map(fn($f) => [
        '@type' => 'Question',
        'name' => is_object($f) ? $f->question : $f['question'],
        'acceptedAnswer' => ['@type' => 'Answer', 'text' => is_object($f) ? $f->answer : $f['answer']]
    ]);
@endphp

<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@graph": [
        {
            "@type": "WebSite",
            "@id": "{{ $orgUrl }}/#website",
            "url": "{{ $orgUrl }}/",
            "name": "{{ $orgName }}",
            "description": "{{ $description }}",
            "inLanguage": "en-US",
            "publisher": {"@id": "{{ $orgUrl }}/#org"}
        },
        {
            "@type": "Organization",
            "@id": "{{ $orgUrl }}/#org",
            "name": "{{ $orgName }}",
            "url": "{{ $orgUrl }}/",
            "logo": {
                "@type": "ImageObject",
                "url": "{{ $logoUrl }}",
                "width": 220,
                "height": 44
            },
            "email": "{{ $orgEmail }}",
            "telephone": "{{ $orgPhone }}",
            "description": "Website, custom web application, SaaS and digital product development company.",
            "foundingDate": "2019",
            "founder": {"@id": "{{ $orgUrl }}/#founder"},
            "sameAs": [
                "{{ $founderLinkedin }}"
            ],
            "areaServed": ["US", "CA", "AU", "NZ", "GB"],
            "hasOfferCatalog": {
                "@type": "OfferCatalog",
                "name": "Services",
                "itemListElement": {!! $servicesForSchema->toJson() !!}
            }
        },
        {
            "@type": "Person",
            "@id": "{{ $orgUrl }}/#founder",
            "name": "{{ $founderName }}",
            "jobTitle": "{{ $settings['founder_title'] ?? 'Founder & Technology Lead' }}",
            "worksFor": {"@id": "{{ $orgUrl }}/#org"},
            "sameAs": ["{{ $founderLinkedin }}"]
        },
        @if($faqForSchema->count() > 0)
        {
            "@type": "FAQPage",
            "mainEntity": {!! $faqForSchema->toJson() !!}
        },
        @endif
        {
            "@type": "BreadcrumbList",
            "itemListElement": [
                {"@type": "ListItem", "position": 1, "name": "Home", "item": "{{ $orgUrl }}/"}
            ]
        }
    ]
}
</script>

<!-- Google tag (gtag.js) - Add your GA4 measurement ID in settings as 'ga_measurement_id' -->
@if($settings['ga_measurement_id'] ?? false)
<script async src="https://www.googletagmanager.com/gtag/js?id={{ $settings['ga_measurement_id'] }}"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', '{{ $settings['ga_measurement_id'] }}');
</script>
@endif

<!-- Google Site Verification -->
@if($settings['google_site_verification'] ?? false)
<meta name="google-site-verification" content="{{ $settings['google_site_verification'] }}">
@endif

<!-- Bing Site Verification -->
@if($settings['bing_site_verification'] ?? false)
<meta name="msvalidate.01" content="{{ $settings['bing_site_verification'] }}">
@endif
